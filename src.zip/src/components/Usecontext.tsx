import React,{useContext,createContext} from "react";

type usercontexttype={
    name:String,
    email:String;
}
const Usercontext=createContext<usercontexttype| null>(null);

export const Context=()=>{
    const user:usercontexttype={name:'john',email:'john@gmail.com'}
    return(<>
        <Usercontext.Provider value={user}>
           <Dashboard/>
        </Usercontext.Provider>
    </>)
}

export const Dashboard=()=>{
    const user=useContext(Usercontext);
    if(!user){
        <p>Loading...</p>
    }
    return(
        <>
            <div>Welcome {user?.name}</div>
            <div>Email: {user?.email}</div>
        </>
    )
}