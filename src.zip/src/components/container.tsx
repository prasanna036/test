type containerprops={
    styles:React.CSSProperties;
}

const Container=(props:containerprops)=>{
    return(
    <>
        <p style={props.styles}>Hello</p>
    </>)
}
export default Container;