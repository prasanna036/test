import { useState } from "react";
type authUser={
    name:String,
    email:String
}

export const User=()=>{
    const [user,setuser]=useState <authUser | null>(null);
    const handlelogin=()=>{
        setuser(
            {
                name:'prasanna',
                email:'prasanna@gmail.com'
            }
        )
    }
    const handlelogout=()=>{
        setuser(null);
    }
    return(<>
            <button onClick={handlelogin}>Login</button><br></br>
            <button onClick={handlelogout}>Logout</button>
            <div>User name is {user?.name}</div>
            <div>User email is {user?.email}</div>
        </>)
}