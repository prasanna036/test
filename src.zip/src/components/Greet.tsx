type greetprops={
    name:string;
    messagecount?:1 |2 |3;
    isloggedin:boolean;
}

const Greet=(props:greetprops)=>{
    const {messagecount=0}=props;
    return(
        <>
        <h2>
        {props.isloggedin ?
           `Welcome ${props.name} messagecount ${props.messagecount}!`:`welcome guest`}
         </h2>
        </>
    )
}
export default Greet;