import React from "react";

type buttonprops={
    handleclick:(event:React.MouseEvent<HTMLButtonElement>,id:number)=>void;
}

const Button=(props:buttonprops)=>{
    return(
        <button onClick={(event)=>props.handleclick(event,1)}>Click</button>
    )
}
export default Button;
