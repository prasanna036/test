type headingprops={
    children:string;
}

const heading=(props:headingprops)=>{
    return (
        <>
          <h2>{props.children}</h2>
        </>
    )
}
export default heading;