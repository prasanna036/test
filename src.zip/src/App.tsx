import React from 'react';
import logo from './logo.svg';
import './App.css';
import Greet from './components/Greet';
import Person from './components/Person';
import Heading from './components/Heading';
import Button from './components/Button';
import Container from './components/container';
import { User } from './components/Usestate';
import { Counter } from './components/Usereducer';
import { Context } from './components/Usecontext';

function App() {
  const personName={
    first:'prasanna',
    last:'praba'
  }
  return (
    <div className="App">
      <Greet name='prasanna' messagecount={1} isloggedin={true} />
      <Person name={personName} />
      <Heading> This is a heading</Heading>
      <Button handleclick={(event,id)=>{
        console.log("button clicked",event,id);
      }}/>
      <Container styles={{border:'4px solid black',padding:'1rem'}}/>
      <User/>
      <Counter/>
      <Context/>
    </div>
  );
}

export default App;
